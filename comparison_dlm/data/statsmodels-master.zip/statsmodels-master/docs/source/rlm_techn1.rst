.. module:: statsmodels.rlm
   :synopsis: Outlier robust linear models

.. currentmodule:: statsmodels.rlm


.. _rlm_techn1:

Weight Functions
----------------

Andrew's Wave

.. image:: images/aw.png

Hampel 17A

.. image:: images/hl.png

Huber's t

.. image:: images/ht.png

Least Squares

.. image:: images/ls.png

Ramsay's Ea

.. image:: images/re.png

Trimmed Mean

.. image:: images/tm.png

Tukey's Biweight

.. image:: images/tk.png


